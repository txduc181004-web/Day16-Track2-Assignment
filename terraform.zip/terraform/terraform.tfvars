# Free plan accounts cannot launch t3.medium; c7i-flex.large is free-tier eligible (2 vCPU / 4 GB)
cpu_instance_type = "c7i-flex.large"
